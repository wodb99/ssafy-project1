from django.apps import AppConfig


class GoldsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'golds'
