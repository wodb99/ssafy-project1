from django.apps import AppConfig


class FinancialProductsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'financial_products'
